import asyncio
import importlib
import json
import math
import os
import random
import re
import sys
import traceback

import pygame

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FPS = 60
PASTEL_HEADER = (162, 196, 201)
PASTEL_HEADER_DARK = (125, 165, 172)
STRAWBERRY_CREAM = (244, 194, 194)
STRAWBERRY_ROSE = (232, 197, 200)
LEMON_MERINGUE = (243, 229, 171)
PRIMARY_BUTTON_COLOR = (244, 235, 179)
WARM_CREAM = (250, 248, 245)
PASTEL_BORDER = (190, 155, 153)
PASTEL_TEXT = (61, 61, 61)
PASTEL_MUTED = (112, 111, 108)

arabic_reshaper = None
bidi_get_display = None
try:
    arabic_reshaper = importlib.import_module("arabic_" + "reshaper")
except Exception:
    arabic_reshaper = None
try:
    bidi_algorithm = importlib.import_module(".".join(("bidi", "algorithm")))
    bidi_get_display = bidi_algorithm.get_display
except Exception:
    bidi_get_display = None

ARABIC_FORMS = {
    "ا": ("\ufe8d", "\ufe8e", None, None),
    "ب": ("\ufe8f", "\ufe90", "\ufe91", "\ufe92"),
    "ت": ("\ufe95", "\ufe96", "\ufe97", "\ufe98"),
    "ث": ("\ufe99", "\ufe9a", "\ufe9b", "\ufe9c"),
    "ج": ("\ufe9d", "\ufe9e", "\ufe9f", "\ufea0"),
    "ح": ("\ufea1", "\ufea2", "\ufea3", "\ufea4"),
    "خ": ("\ufea5", "\ufea6", "\ufea7", "\ufea8"),
    "د": ("\ufea9", "\ufeaa", None, None),
    "ذ": ("\ufeab", "\ufeac", None, None),
    "ر": ("\ufead", "\ufeae", None, None),
    "ز": ("\ufeaf", "\ufeb0", None, None),
    "س": ("\ufeb1", "\ufeb2", "\ufeb3", "\ufeb4"),
    "ش": ("\ufeb5", "\ufeb6", "\ufeb7", "\ufeb8"),
    "ص": ("\ufeb9", "\ufeba", "\ufebb", "\ufebc"),
    "ض": ("\ufebd", "\ufebe", "\ufebf", "\ufec0"),
    "ط": ("\ufec1", "\ufec2", "\ufec3", "\ufec4"),
    "ظ": ("\ufec5", "\ufec6", "\ufec7", "\ufec8"),
    "ع": ("\ufec9", "\ufeca", "\ufecb", "\ufecc"),
    "غ": ("\ufecd", "\ufece", "\ufecf", "\ufed0"),
    "ف": ("\ufed1", "\ufed2", "\ufed3", "\ufed4"),
    "ق": ("\ufed5", "\ufed6", "\ufed7", "\ufed8"),
    "ك": ("\ufed9", "\ufeda", "\ufedb", "\ufedc"),
    "ل": ("\ufedd", "\ufede", "\ufedf", "\ufee0"),
    "م": ("\ufee1", "\ufee2", "\ufee3", "\ufee4"),
    "ن": ("\ufee5", "\ufee6", "\ufee7", "\ufee8"),
    "ه": ("\ufee9", "\ufeea", "\ufeeb", "\ufeec"),
    "و": ("\ufeed", "\ufeee", None, None),
    "ي": ("\ufef1", "\ufef2", "\ufef3", "\ufef4"),
    "ى": ("\ufef5", "\ufef6", None, None),
    "ة": ("\ufe93", "\ufe94", None, None),
    "ء": ("\ufe80", "\ufe80", None, None),
}

CASE_TEMPLATES = [
    {
        "id": "teen",
        "title": "حالة اليوم هي: مراهقة تعاني من الم شديد",
        "goal": "مهمتك تخفيف الألم مع مراعاة صغر سنها",
        "pain_start": 50,
        "budget_start": 2800,
        "quotes": {
            "happy": "احس بتحسن اليوم، لكن الألم يعود.",
            "hurting": "قالوا لي إنه الم عادي!",
            "crying": "ما اقدر اتحمل ذاالألم.",
        },
        "modifiers": {"clinical": 2, "ca125": -2, "ultrasound": 3, "mri": 2},
    },
    {
        "id": "pregnancy",
        "title": "حالة اليوم هي: متزوجة ترغب في الحمل",
        "goal": "مهمتك تخفيف الألم مع رغبتها بالحمل",
        "pain_start": 45,
        "budget_start": 3200,
        "quotes": {
            "happy": "أتمنى أن أجد إجابة وأطمئن.",
            "hurting": "أخاف أن يؤثر الألم على حياتي.",
            "crying": "مافيه حل؟ ",
        },
        "modifiers": {"clinical": 1, "ca125": 2, "ultrasound": 3, "mri": 1},
    },
    {
        "id": "comfort",
        "title": "حالة اليوم هي: امرأة تريد الراحة فقط",
        "goal": "مهمتك تخفيف الألم مع مراعاة الراحة والميزانية",
        "pain_start": 55,
        "budget_start": 2400,
        "quotes": {
            "happy": "أريد أيامًا أعيشها براحة.",
            "hurting": "متى العلاج؟",
            "crying": "تعبت من الألم كل يوم.",
        },
        "modifiers": {"clinical": 0, "ca125": -1, "ultrasound": 2, "mri": 3},
    },
]

TESTS = {
    "clinical": {
        "name": "الفحص السريري",
        "cost": 100,
        "days": 3,
        "certainty": 20,
        "room": "العيادة",
        "description": "يساعد الفحص السريري في رصد مؤشرات الألم والتاريخ الطبي، ولا يمنح تشخيصاً مؤكداً بمفرده",
        "result": "اشتباه مبدئي ببطانة الرحم المهاجرة  ",
    },
    "ca125": {
        "name": "تحليل CA-125",
        "cost": 150,
        "days": 4,
        "certainty": 15,
        "room": "المختبر",
        "description": "يرتفع بحالات الالتهاب لكنه فحص مكمل ولا يحسم التشخيص بمفرده",
        "result": "ارتفاع بسيط CA-125 في لكنه ليس تشخيصا نهائيا",
    },
    "hcg": {
        "name": "تحليل هرمون الحمل hCG",
        "cost": 100,
        "days": 2,
        "certainty": 0,
        "room": "المختبر",
        "description": "فحص لاستبعاد الحمل أو الحمل خارج الرحم",
        "result": "لا يوجد حمل وليس له صلة بالتشخيص",
    },
    "cbc": {
        "name": "صورة دم كاملة CBC",
        "cost": 80,
        "days": 1,
        "certainty": 5,
        "room": "المختبر",
        "description": "قد يقيّم فقر الدم، لكنه ليس اختبارًا تشخيصيًا للمرض.",
        "result": "نتيجة طبيعية",
    },
    "ultrasound": {
        "name": "موجات فوق صوتية حوضية",
        "cost": 250,
        "days": 5,
        "certainty": 25,
        "room": "التصوير",
        "description": "كشف عن أكياس المبيض والالتصاقات الكبيرة، ولكنها قد تفوت النقاط السطحية الصغيرة ",
        "result": " هناك اكياس محتلمة على المبيض، لكن لا يمكن تأكيد التشخيص",
    },
    "xray": {
        "name": "أشعة سينية سريعة X-Ray",
        "cost": 120,
        "days": 1,
        "certainty": 0,
        "room": "التصوير",
        "description": "فحص للانسخة الصلبة",
        "result": "فحص غير مفيد للتشخيص",
    },
    "mri": {
        "name": "رنين مغناطيسي للحوض MRI",
        "cost": 600,
        "days": 10,
        "certainty": 35,
        "room": "غرفة الرنين",
        "description": "يعطي صورة أدق لبعض الحالات",
        "result": " نم رصد التصاقات",
    },
    "laparoscopy": {
        "name": "تنظير البطن التشخيصي Laparoscopy",
        "cost": 1500,
        "days": 14,
        "certainty": 100,
        "room": "الجراحة",
        "description": "إجراء جراحي يتيح الرؤية المباشرة للأنسجة المهاجرة وأخذ خزعة لتأكيد المرض",
        "result": "تشخيص قاطع",
    },
}

ROOM_TEST_OPTIONS = {
    "clinical": ("clinical",),
    "ca125": ("ca125", "hcg", "cbc"),
    "ultrasound": ("ultrasound", "xray"),
    "mri": ("mri",),
    "laparoscopy": ("laparoscopy",),
}

ROOM_BUTTON_RECTS = {
    test_id: pygame.Rect(1068, 112 + index * 48, 188, 40)
    for index, test_id in enumerate(ROOM_TEST_OPTIONS)
}
ROOM_PANEL_RECT = pygame.Rect(270, 102, 760, 510)
ROOM_OPTION_BUTTON_RECTS = {
    room_id: [
        pygame.Rect(850, 222 + option_index * 112, 150, 52)
        for option_index, _ in enumerate(options)
    ]
    for room_id, options in ROOM_TEST_OPTIONS.items()
}
ROOM_PANEL_CLOSE_RECT = pygame.Rect(555, 560, 190, 42)
CONFIRM_DIAGNOSIS_RECT = pygame.Rect(28, 630, 330, 72)
RECEPTION_DESK_RECT = pygame.Rect(400, 90, 160, 105)
RECEPTION_INFO_CLOSE_RECT = pygame.Rect(535, 500, 210, 54)

DRUGS = {
    "nsaids": {
        "label": "مضادات الالتهاب",
        "cost": 40,
        "explanation": "تخفف الألم عبر إعاقة COX-2.",
        "pain_effect": 18,
    },
    "letrozole": {
        "label": "ليتروزول",
        "cost": 120,
        "explanation": "يثبط الأروماتاز (الاروماتاز يزيد الاستروجين فيزيد المرض) .",
        "pain_effect": 8,
    },
    "gnrh": {
        "label": "مثبطات GnRH",
        "cost": 350,
        "explanation": "تثبط افراز الاستروجين.",
        "pain_effect": 12,
    },
}

IDEAL_TREATMENTS = {
    "teen": {"nsaids", "gnrh"},
    "pregnancy": {"nsaids"},
    "comfort": {"nsaids", "letrozole"},
}

def resource_path(relative_path):
    return os.path.join(BASE_DIR, *relative_path.split("/"))


def can_move_to(map_mask, x, y, player_width=40, player_height=60):
    check_points = (
        (int(x + player_width * fraction), int(y + player_height - offset))
        for fraction in (0.2, 0.5, 0.8)
        for offset in (5, 12)
    )
    for px, py in check_points:
        if not (0 <= px < map_mask.get_width() and 0 <= py < map_mask.get_height()):
            return False
        color = map_mask.get_at((px, py))
        if color.r < 30 and color.g < 30 and color.b < 30:
            return False
    return True


def fallback_shape(text):
    shaped = []
    for index, character in enumerate(text):
        forms = ARABIC_FORMS.get(character)
        if forms is None:
            shaped.append(character)
            continue
        previous = ARABIC_FORMS.get(text[index - 1]) if index > 0 else None
        following = ARABIC_FORMS.get(text[index + 1]) if index + 1 < len(text) else None
        joins_previous = previous is not None and previous[2] is not None and forms[1] is not None
        joins_next = following is not None and forms[2] is not None and following[1] is not None
        if joins_previous and joins_next and forms[3] is not None:
            shaped.append(forms[3])
        elif joins_previous:
            shaped.append(forms[1])
        elif joins_next:
            shaped.append(forms[2])
        else:
            shaped.append(forms[0])
    return "".join(shaped)


def fallback_bidi(text):
    tokens = re.findall(r"[A-Za-z0-9]+|[\u0600-\u06ff\ufb50-\ufeff]+|.", text)
    return "".join(
        token[::-1] if re.match(r"[\u0600-\u06ff\ufb50-\ufeff]", token) else token
        for token in reversed(tokens)
    )


def display_arabic(text):
    try:
        shaped = arabic_reshaper.reshape(text) if arabic_reshaper else fallback_shape(text)
    except Exception:
        shaped = fallback_shape(text)
    try:
        return bidi_get_display(shaped) if bidi_get_display else fallback_bidi(shaped)
    except Exception:
        return fallback_bidi(shaped)


def load_font(size):
    return pygame.font.Font(resource_path("assets/fonts/arabic_pixel.ttf"), size)


def render_text(font, text, color):
    display_text = display_arabic(str(text))
    return font.render(display_text, False, color)


def draw_button(surface, rect, label, font, hovered=False, primary=False):
    shadow = rect.move(0, 3)
    pygame.draw.rect(surface, PASTEL_BORDER, shadow, border_radius=18)
    color = PRIMARY_BUTTON_COLOR if primary else LEMON_MERINGUE if hovered else STRAWBERRY_ROSE
    pygame.draw.rect(surface, color, rect, border_radius=18)
    border = PASTEL_HEADER_DARK if hovered else PASTEL_BORDER
    pygame.draw.rect(surface, border, rect, 2, border_radius=18)
    text = render_text(font, label, PASTEL_TEXT)
    surface.blit(text, text.get_rect(center=rect.center))


def draw_menu(surface, state, fonts, map_image, mouse_pos):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    panel = pygame.Rect(300, 70, 680, 580)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=18)
    pygame.draw.rect(surface, PASTEL_BORDER, panel, 4, border_radius=18)
    title = render_text(fonts["title"], "ساعة التشخيص", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 120)))
    slogan_lines = (
        ("هل تستطيع تشخيص ومعالجة المرض؟", (640, 175)),
        ("أظهر قدراتك!", (640, 215)),
    )
    for line, center in slogan_lines:
        slogan = render_text(fonts["button"], line, PASTEL_TEXT)
        surface.blit(slogan, slogan.get_rect(center=center))

    if state == "menu":
        labels = ["ابدئي اللعب", "طريقة اللعب", "لوحة الصدارة"]
        for index, label in enumerate(labels):
            rect = pygame.Rect(450, 260 + index * 92, 380, 64)
            draw_button(surface, rect, label, fonts["button"], rect.collidepoint(mouse_pos))
    else:
        if state == "how":
            lines = [
                "طريقة اللعب: ستظهر حالة مرضية والمطلوب منك تشخيصها واكتشاف العلاج الأنسب.",
                "من القائمة اليمنى اختر الإجراءات: تحليل مختبري - أشعة - تقييم العيادة.",
                "عند الضغط على تأكيد التشخيص ستنتقل لخطوة العلاج واللعبة المصغرة.. استمتع بها!",
                "تنويه: تنتهي اللعبة إذا وصل مؤشر الألم العلوي إلى 100 بالمئة.",
                "ملاحظة: اللعبة مجرد محاكاة تعليمية .",
            ]
        elif state == "name":
            lines = []
        else:
            lines = [
                "لا توجد نتائج حتى الآن.",
                "تُحفظ النتائج على هذا الجهاز فقط.",
            ]
        line_y = 242
        line_font = fonts["small"] if state == "how" else fonts["body"]
        max_width = 620 if state == "how" else 640
        for line in lines:
            words = line.split()
            wrapped = []
            current_line = ""
            for word in words:
                candidate = f"{current_line} {word}".strip()
                if current_line and line_font.size(display_arabic(candidate))[0] > max_width:
                    wrapped.append(current_line)
                    current_line = word
                else:
                    current_line = candidate
            if current_line:
                wrapped.append(current_line)
            for wrapped_line in wrapped:
                text = render_text(line_font, wrapped_line, PASTEL_TEXT)
                surface.blit(text, text.get_rect(center=(640, line_y)))
                line_y += 30 if state == "how" else 56
            if state == "how":
                line_y += 12
        if state != "name":
            draw_button(surface, pygame.Rect(500, 530, 280, 62), "عودة", fonts["button"])


def new_case(previous_case_id):
    choices = [item for item in CASE_TEMPLATES if item["id"] != previous_case_id]
    template = random.choice(choices)
    case = dict(template)
    case["pain"] = float(template["pain_start"])
    case["budget"] = template["budget_start"]
    case["tests_used"] = set()
    return case


def patient_mood(pain):
    if pain < 35:
        return "happy"
    if pain <= 70:
        return "hurting"
    return "crying"


def patient_quote(case):
    return case["quotes"][patient_mood(case["pain"])]


def is_portrait():
    if sys.platform == "emscripten":
        try:
            import platform as web_platform
            return web_platform.window.innerWidth < web_platform.window.innerHeight
        except Exception:
            return False
    return pygame.display.get_surface().get_width() < pygame.display.get_surface().get_height()


def prompt_web_name():
    import platform as web_platform
    try:
        return web_platform.window.prompt("ما اسم المعالجة")
    except Exception as window_error:
        raise RuntimeError(f"نافذة المتصفح غير متاحة: {window_error}") from window_error


def draw_meter(surface, x, y, width, value, color, label, fonts):
    label_surface = render_text(fonts["small"], label, PASTEL_TEXT)
    surface.blit(label_surface, (x, y))
    pygame.draw.rect(surface, WARM_CREAM, (x, y + 24, width, 8), border_radius=4)
    fill_width = int(width * max(0, min(100, value)) / 100)
    if fill_width:
        pygame.draw.rect(surface, color, (x, y + 24, fill_width, 8), border_radius=4)


def draw_hud(surface, case, day, certainty, fonts):
    pygame.draw.rect(surface, PASTEL_HEADER, (0, 0, SCREEN_WIDTH, 64))
    pygame.draw.line(surface, PASTEL_HEADER_DARK, (0, 63), (SCREEN_WIDTH, 63), 2)
    meter_width = 260
    draw_meter(
        surface, 34, 7, meter_width, case["pain"], STRAWBERRY_CREAM,
        f"الألم {int(case['pain'])}", fonts,
    )
    budget_percent = 100 * case["budget"] / case["budget_start"]
    draw_meter(
        surface, 338, 7, meter_width, budget_percent, STRAWBERRY_ROSE,
        f"الميزانية {case['budget']}", fonts,
    )
    draw_meter(
        surface, 642, 7, meter_width, certainty, LEMON_MERINGUE,
        f"اليقين {int(certainty)}٪", fonts,
    )
    day_label = render_text(fonts["small"], f"اليوم {day}", PASTEL_TEXT)
    surface.blit(day_label, day_label.get_rect(midright=(1248, 24)))


def draw_patient(surface, x, y, pain, quote, fonts):
    mood = patient_mood(pain)
    outline = (71, 58, 61)

    # Bed and pillow sit behind the patient, matching the map's pixel-art palette.
    pygame.draw.rect(surface, outline, (x - 5, y + 58, 76, 25))
    pygame.draw.rect(surface, (181, 194, 198), (x - 2, y + 60, 70, 18))
    pygame.draw.rect(surface, (225, 224, 204), (x + 42, y + 48, 22, 14))
    pygame.draw.rect(surface, (97, 113, 121), (x + 3, y + 79, 5, 15))
    pygame.draw.rect(surface, (97, 113, 121), (x + 57, y + 79, 5, 15))

    # Seated legs, arms, and a shaded teal top replace the former purple block.
    pygame.draw.rect(surface, outline, (x + 12, y + 55, 23, 20))
    pygame.draw.rect(surface, (83, 101, 125), (x + 15, y + 58, 17, 15))
    pygame.draw.rect(surface, outline, (x + 34, y + 55, 23, 20))
    pygame.draw.rect(surface, (83, 101, 125), (x + 37, y + 58, 17, 15))
    pygame.draw.rect(surface, outline, (x + 10, y + 29, 43, 34))
    pygame.draw.rect(surface, (67, 137, 132), (x + 13, y + 32, 37, 28))
    pygame.draw.rect(surface, (115, 177, 160), (x + 17, y + 34, 7, 20))
    pygame.draw.rect(surface, (49, 104, 111), (x + 27, y + 34, 20, 25))
    pygame.draw.rect(surface, outline, (x + 5, y + 34, 12, 27))
    pygame.draw.rect(surface, (214, 165, 133), (x + 8, y + 39, 7, 17))
    pygame.draw.rect(surface, outline, (x + 47, y + 34, 12, 27))
    pygame.draw.rect(surface, (214, 165, 133), (x + 49, y + 39, 7, 17))

    # Pixel-art head with side-swept dark hair and mood-specific expression.
    pygame.draw.rect(surface, outline, (x + 15, y + 1, 34, 32))
    pygame.draw.rect(surface, (223, 177, 143), (x + 18, y + 5, 28, 25))
    pygame.draw.rect(surface, (66, 52, 54), (x + 13, y, 35, 10))
    pygame.draw.rect(surface, (66, 52, 54), (x + 13, y + 5, 7, 19))
    pygame.draw.rect(surface, (66, 52, 54), (x + 41, y + 7, 7, 18))
    pygame.draw.rect(surface, (104, 73, 65), (x + 18, y + 3, 18, 4))
    if mood == "happy":
        pygame.draw.rect(surface, outline, (x + 23, y + 13, 4, 4))
        pygame.draw.rect(surface, outline, (x + 37, y + 13, 4, 4))
        pygame.draw.rect(surface, (157, 76, 79), (x + 27, y + 22, 11, 3))
    elif mood == "hurting":
        pygame.draw.rect(surface, outline, (x + 22, y + 14, 5, 3))
        pygame.draw.rect(surface, outline, (x + 37, y + 14, 5, 3))
        pygame.draw.rect(surface, (157, 76, 79), (x + 29, y + 22, 8, 3))
    else:
        pygame.draw.rect(surface, outline, (x + 22, y + 15, 5, 3))
        pygame.draw.rect(surface, outline, (x + 37, y + 15, 5, 3))
        pygame.draw.rect(surface, (82, 155, 202), (x + 42, y + 19, 3, 8))
        pygame.draw.rect(surface, (157, 76, 79), (x + 29, y + 21, 8, 5))

    bubble = pygame.Rect(x - 300, y - 78, 360, 50)
    pygame.draw.rect(surface, outline, bubble.inflate(4, 4), border_radius=10)
    pygame.draw.rect(surface, WARM_CREAM, bubble, border_radius=9)
    pygame.draw.polygon(
        surface,
        outline,
        [
            (x + 12, bubble.bottom - 1),
            (x + 37, bubble.bottom - 1),
            (x + 29, y - 2),
        ],
    )
    pygame.draw.polygon(
        surface,
        (250, 246, 232),
        [
            (x + 15, bubble.bottom - 1),
            (x + 34, bubble.bottom - 1),
            (x + 29, y + 1),
        ],
    )
    quote_surface = render_text(fonts["small"], quote, PASTEL_TEXT)
    surface.blit(quote_surface, quote_surface.get_rect(center=bubble.center))


def draw_room_navigation(surface, fonts, used_tests, mouse_pos):
    panel = pygame.Rect(1044, 78, 220, 280)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=20)
    pygame.draw.rect(surface, PASTEL_BORDER, panel, 2, border_radius=20)
    title = render_text(fonts["small"], "خيارات الفحص", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(panel.centerx, panel.y + 17)))
    for test_id, rect in ROOM_BUTTON_RECTS.items():
        hovered = rect.collidepoint(mouse_pos)
        label = TESTS[test_id]["room"]
        if any(option in used_tests for option in ROOM_TEST_OPTIONS[test_id]):
            label = f"{label} - تم"
        draw_button(surface, rect, label, fonts["small"], hovered)


def draw_confirm_diagnosis(surface, fonts, certainty, mouse_pos):
    rect = CONFIRM_DIAGNOSIS_RECT
    enabled = certainty >= 70
    if enabled:
        pygame.draw.rect(
            surface, PASTEL_HEADER_DARK, rect.inflate(12, 12), 4, border_radius=42,
        )
        pygame.draw.rect(
            surface, STRAWBERRY_CREAM, rect.inflate(6, 6), 2, border_radius=39,
        )
        pygame.draw.rect(surface, PASTEL_BORDER, rect.move(0, 5), border_radius=38)
        pygame.draw.rect(surface, PRIMARY_BUTTON_COLOR, rect, border_radius=36)
        pygame.draw.rect(surface, PASTEL_HEADER_DARK, rect, 4, border_radius=36)
        hovered = rect.collidepoint(mouse_pos)
        if hovered:
            pygame.draw.rect(surface, WARM_CREAM, rect, 2, border_radius=36)
        label = "تأكيد التشخيص"
        color = PASTEL_TEXT
    else:
        pygame.draw.rect(surface, PASTEL_HEADER, rect, border_radius=30)
        pygame.draw.rect(surface, PASTEL_BORDER, rect, 2, border_radius=30)
        label = "لازم يقين 70٪ لتأكيد التشخيص"
        color = PASTEL_MUTED
    text_font = fonts["button"] if enabled else fonts["small"]
    text = render_text(text_font, label, color)
    surface.blit(text, text.get_rect(center=rect.center))


def draw_reception_info(surface, fonts, mouse_pos):
    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((35, 44, 48, 150))
    surface.blit(overlay, (0, 0))

    panel = pygame.Rect(250, 190, 780, 390)
    pygame.draw.rect(surface, PASTEL_BORDER, panel.inflate(8, 8), border_radius=24)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=22)
    pygame.draw.rect(surface, PASTEL_HEADER, panel, 3, border_radius=22)

    title = render_text(fonts["title"], "عن بطانة الرحم المهاجرة", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(panel.centerx, panel.y + 70)))

    paragraph = (
        "حالة ينمو فيها نسيج مشابه لبطانة الرحم خارج الرحم، مما يسبب ألمًا مزمنًا "
        "وتأخرًا في التشخيص. لا يوجد حتى الآن علاج يزيل بطانة الرحم المهاجرة نهائيًا "
        "لدى جميع المصابات، لكن يمكن السيطرة على الألم والأعراض بخيارات دوائية أو "
        "جراحية تُحدّد وفق شدة الأعراض، ومكان الآفات، والعمر، والرغبة في الحمل. "
        "هدف هذه اللعبة هو رفع التوعية وتقليل رحلة المعاناة للمريضات."
    )
    words = paragraph.split()
    lines = []
    current_line = ""
    max_width = panel.width - 100
    for word in words:
        candidate = f"{current_line} {word}".strip()
        if current_line and fonts["small"].size(display_arabic(candidate))[0] > max_width:
            lines.append(current_line)
            current_line = word
        else:
            current_line = candidate
    if current_line:
        lines.append(current_line)
    line_spacing = 30
    text_area_center_y = panel.y + 220
    first_line_y = text_area_center_y - (len(lines) - 1) * line_spacing / 2
    for index, line in enumerate(lines):
        text = render_text(fonts["small"], line, PASTEL_TEXT)
        surface.blit(
            text,
            text.get_rect(center=(panel.centerx, int(first_line_y + index * line_spacing))),
        )

    draw_button(
        surface,
        RECEPTION_INFO_CLOSE_RECT,
        "إغلاق",
        fonts["button"],
        RECEPTION_INFO_CLOSE_RECT.collidepoint(mouse_pos),
    )


def draw_doctor(surface, player_image, player_pos):
    surface.blit(player_image, (int(player_pos[0]), int(player_pos[1])))


def draw_map_scene(surface, case, day, certainty, fonts, map_image,
                   player_image, player_pos, used_tests, mouse_pos, show_confirm):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    draw_hud(surface, case, day, certainty, fonts)
    draw_room_navigation(surface, fonts, used_tests, mouse_pos)
    draw_doctor(surface, player_image, player_pos)
    draw_patient(surface, 968, 472, case["pain"], patient_quote(case), fonts)
    if show_confirm:
        draw_confirm_diagnosis(surface, fonts, certainty, mouse_pos)


def draw_name_screen(surface, fonts, map_image, name_text, editing, notice):
    draw_menu(surface, "name", fonts, map_image, (0, 0))
    pygame.draw.rect(surface, WARM_CREAM, (390, 350, 500, 60), border_radius=14)
    border = PASTEL_HEADER_DARK if editing else PASTEL_BORDER
    pygame.draw.rect(surface, border, (390, 350, 500, 60), 3, border_radius=14)
    shown_name = name_text if name_text else "انقري هنا واكتبي اسمك"
    name_surface = render_text(fonts["body"], shown_name, PASTEL_TEXT)
    surface.blit(name_surface, name_surface.get_rect(center=(640, 380)))
    draw_button(
        surface, pygame.Rect(500, 450, 280, 62), "ابدئي الحالة",
        fonts["button"], primary=True,
    )
    if notice:
        notice_surface = render_text(fonts["small"], notice, (152, 72, 81))
        surface.blit(notice_surface, notice_surface.get_rect(center=(640, 535)))


def draw_case_intro(surface, case, patient_name, fonts, map_image):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    panel = pygame.Rect(220, 100, 840, 520)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=20)
    pygame.draw.rect(surface, PASTEL_BORDER, panel, 4, border_radius=20)
    title = render_text(fonts["title"], case["title"], PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 180)))
    patient = render_text(fonts["body"], f"المعالجة: {patient_name}", PASTEL_TEXT)
    surface.blit(patient, patient.get_rect(center=(640, 260)))
    goal = render_text(fonts["body"], case["goal"], PASTEL_TEXT)
    surface.blit(goal, goal.get_rect(center=(640, 320)))
    quote = render_text(fonts["body"], patient_quote(case), PASTEL_HEADER_DARK)
    surface.blit(quote, quote.get_rect(center=(640, 390)))
    note = render_text(fonts["small"], "هذا نموذج تعليمي مبسط .", PASTEL_TEXT)
    surface.blit(note, note.get_rect(center=(640, 470)))
    draw_button(
        surface, pygame.Rect(500, 520, 280, 62), "إلى المستشفى",
        fonts["button"], primary=True,
    )


def draw_room_panel(surface, room_id, case, fonts, notice, mouse_pos):
    panel = ROOM_PANEL_RECT
    pygame.draw.rect(surface, PASTEL_BORDER, panel.inflate(8, 8), border_radius=24)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=22)
    pygame.draw.rect(surface, PASTEL_HEADER, panel, 3, border_radius=22)
    room_title = render_text(fonts["title"], TESTS[room_id]["room"], PASTEL_TEXT)
    surface.blit(room_title, room_title.get_rect(center=(panel.centerx, panel.y + 35)))
    subtitle = render_text(
        fonts["small"],
        "اختاري فحصًا؛ يمكن إجراء أكثر من فحص في الغرفة نفسها.",
        PASTEL_MUTED,
    )
    surface.blit(subtitle, subtitle.get_rect(center=(panel.centerx, panel.y + 72)))

    for index, test_id in enumerate(ROOM_TEST_OPTIONS[room_id]):
        test = TESTS[test_id]
        row = pygame.Rect(panel.x + 18, panel.y + 96 + index * 112, panel.width - 36, 100)
        pygame.draw.rect(surface, STRAWBERRY_ROSE, row, border_radius=14)
        pygame.draw.rect(surface, PASTEL_BORDER, row, 2, border_radius=14)
        name = render_text(fonts["small"], test["name"], PASTEL_TEXT)
        surface.blit(name, (row.x + 16, row.y + 10))
        certainty_label = (
            "اليقين 100٪"
            if test_id == "laparoscopy"
            else f"اليقين +{test['certainty']}٪"
        )
        details = render_text(
            fonts["small"],
            f"التكلفة {test['cost']}  |  الأيام {test['days']}  |  {certainty_label}",
            PASTEL_TEXT,
        )
        surface.blit(details, (row.x + 16, row.y + 40))
        result = render_text(fonts["small"], test["result"], PASTEL_HEADER_DARK)
        surface.blit(result, (row.x + 16, row.y + 68))

        action_rect = ROOM_OPTION_BUTTON_RECTS[room_id][index]
        if test_id in case["tests_used"]:
            action = "تم الفحص"
            enabled = False
        elif case["budget"] < test["cost"]:
            action = "غير متاح"
            enabled = False
        else:
            action = "إجراء"
            enabled = True
        if enabled:
            draw_button(
                surface, action_rect, action, fonts["small"],
                action_rect.collidepoint(mouse_pos),
            )
        else:
            pygame.draw.rect(surface, PASTEL_HEADER, action_rect, border_radius=16)
            pygame.draw.rect(surface, PASTEL_BORDER, action_rect, 2, border_radius=16)
            text = render_text(fonts["small"], action, PASTEL_MUTED)
            surface.blit(text, text.get_rect(center=action_rect.center))

    if notice:
        message = render_text(fonts["small"], notice, PASTEL_TEXT)
        surface.blit(message, message.get_rect(center=(panel.centerx, panel.bottom - 68)))
    draw_button(
        surface,
        ROOM_PANEL_CLOSE_RECT,
        "عودة للخريطة",
        fonts["small"],
        ROOM_PANEL_CLOSE_RECT.collidepoint(mouse_pos),
    )


def rank_for_score(score):
    if score < 300:
        return "متدربة"
    if score < 550:
        return "معالجة ماهرة"
    if score < 800:
        return "أخصائية"
    return "استشارية"


def build_score_breakdown(case, day, treatment_fit, caught, attached, total_spawned):
    speed = max(0, 200 - day * 4)
    immune = max(0, min(200, 200 - attached * 25 + caught * 5))
    wellbeing = int(200 * max(0.0, 1.0 - case["pain"] / 100))
    budget = int(100 * max(0, case["budget"]) / case["budget_start"])
    parts = {
        "speed": speed,
        "treatment": treatment_fit,
        "immune": immune,
        "wellbeing": wellbeing,
        "budget": min(100, budget),
        "caught": caught,
        "attached": attached,
        "total_spawned": total_spawned,
    }
    parts["total"] = sum(parts[key] for key in ("speed", "treatment", "immune", "wellbeing", "budget"))
    parts["rank"] = rank_for_score(parts["total"])
    return parts


def load_leaderboard():
    try:
        if sys.platform == "emscripten":
            import platform as web_platform
            raw = web_platform.window.localStorage.getItem("diagnosis_hour_leaderboard")
            if raw is None:
                return [], ""
            raw = str(raw)
        else:
            try:
                with open(resource_path("leaderboard.json"), "r", encoding="utf-8") as file:
                    raw = file.read()
            except FileNotFoundError:
                return [], ""
        decoded = json.loads(raw)
        if not isinstance(decoded, list):
            raise ValueError("صيغة لوحة الصدارة غير صحيحة.")
        entries = []
        for item in decoded:
            if not isinstance(item, dict):
                continue
            try:
                score = int(item["score"])
                name = str(item["name"]).strip()[:24]
                rank = str(item.get("rank", rank_for_score(score)))
            except (KeyError, TypeError, ValueError):
                continue
            if name:
                entries.append({"name": name, "score": score, "rank": rank})
        entries.sort(key=lambda item: item["score"], reverse=True)
        return entries[:10], ""
    except Exception as error:
        return [], f"تعذّر تحميل النتائج المحفوظة: {error}"


def save_leaderboard_entry(entry):
    entries, error = load_leaderboard()
    if error:
        return entries, error
    entries.append(entry)
    entries.sort(key=lambda item: item["score"], reverse=True)
    entries = entries[:10]
    try:
        payload = json.dumps(entries, ensure_ascii=sys.platform == "emscripten")
        if sys.platform == "emscripten":
            import platform as web_platform
            web_platform.window.localStorage.setItem("diagnosis_hour_leaderboard", payload)
        else:
            with open(resource_path("leaderboard.json"), "w", encoding="utf-8") as file:
                file.write(payload)
        return entries, ""
    except Exception as error:
        return entries, f"تعذّر حفظ النتائج على هذا الجهاز: {error}"


def draw_arrow(surface, start, end, color, radius=54):
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    distance = math.hypot(dx, dy)
    if distance == 0:
        return
    ux, uy = dx / distance, dy / distance
    point_a = (int(start[0] + ux * radius), int(start[1] + uy * radius))
    point_b = (int(end[0] - ux * radius), int(end[1] - uy * radius))
    pygame.draw.line(surface, color, point_a, point_b, 4)
    perpendicular = (-uy, ux)
    tip = point_b
    left = (
        int(tip[0] - ux * 13 + perpendicular[0] * 8),
        int(tip[1] - uy * 13 + perpendicular[1] * 8),
    )
    right = (
        int(tip[0] - ux * 13 - perpendicular[0] * 8),
        int(tip[1] - uy * 13 - perpendicular[1] * 8),
    )
    pygame.draw.polygon(surface, color, (tip, left, right))


def draw_flow_dot(surface, start, end, color, frame, radius=54):
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    distance = math.hypot(dx, dy)
    if distance <= radius * 2:
        return
    fraction = (frame % 60) / 60
    ux, uy = dx / distance, dy / distance
    length = distance - radius * 2
    point = (
        int(start[0] + ux * (radius + length * fraction)),
        int(start[1] + uy * (radius + length * fraction)),
    )
    pygame.draw.circle(surface, color, point, 7)


def draw_treatment_scene(surface, case, selected, fonts, map_image, frame, notice):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    shade = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    shade.fill((250, 248, 245, 220))
    surface.blit(shade, (0, 0))
    title = render_text(fonts["title"], "لغز العلاج", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 42)))
    budget = render_text(fonts["small"], f"الميزانية المتبقية: {case['budget']}", PASTEL_TEXT)
    surface.blit(budget, (28, 30))

    nodes = {
        "aromatase": (420, 230),
        "estradiol": (640, 230),
        "cox2": (860, 230),
        "pge2": (640, 430),
        "ovary": (260, 430),
    }
    blocked = {
        "aromatase": "letrozole" in selected,
        "cox2": "nsaids" in selected,
        "ovary": "gnrh" in selected, 
    }
    edges = (
        ("aromatase", "estradiol", not blocked["aromatase"]),
        ("estradiol", "cox2", True),
        ("cox2", "pge2", not blocked["cox2"]),
        ("pge2", "aromatase", not blocked["aromatase"]),
        ("ovary", "estradiol", not blocked["ovary"]),
    )
    for source, target, active in edges:
        start, end = nodes[source], nodes[target]
        color = PASTEL_HEADER_DARK if active else PASTEL_BORDER
        draw_arrow(surface, start, end, color)
        if active:
            draw_flow_dot(surface, start, end, LEMON_MERINGUE, frame)

    labels = {
        "aromatase": "الأروماتيز",
        "estradiol": "الإستراديول",
        "cox2": "COX-2",
        "pge2": "PGE2",
        "ovary": "المبيض",
    }
    for node, center in nodes.items():
        color = PASTEL_HEADER if blocked.get(node, False) else LEMON_MERINGUE
        pygame.draw.circle(surface, PASTEL_BORDER, center, 58)
        pygame.draw.circle(surface, color, center, 51)
        pygame.draw.circle(surface, PASTEL_HEADER_DARK, center, 51, 3)
        label = render_text(fonts["small"], labels[node], PASTEL_TEXT)
        surface.blit(label, label.get_rect(center=center))
        if blocked.get(node, False):
            pygame.draw.line(surface, STRAWBERRY_CREAM, (center[0] - 25, center[1] - 25), (center[0] + 25, center[1] + 25), 6)
            pygame.draw.line(surface, STRAWBERRY_CREAM, (center[0] + 25, center[1] - 25), (center[0] - 25, center[1] + 25), 6)

    predicted = max(
        0,
        int(case["pain"] - sum(DRUGS[drug]["pain_effect"] for drug in selected)),
    )
    prediction = render_text(fonts["body"], f"الألم المتوقع بعد الاختيارات: {predicted}٪", PASTEL_TEXT)
    surface.blit(prediction, prediction.get_rect(center=(640, 500)))
    card_x = {"nsaids": 20, "letrozole": 440, "gnrh": 860}
    for drug_id, drug in DRUGS.items():
        x = card_x[drug_id]
        card = pygame.Rect(x, 525, 400, 100)
        pygame.draw.rect(surface, WARM_CREAM, card, border_radius=16)
        pygame.draw.rect(surface, PASTEL_BORDER, card, 2, border_radius=16)
        button = pygame.Rect(x + 10, 532, 380, 48)
        draw_button(surface, button, f"{drug['label']} — {drug['cost']}", fonts["small"], drug_id in selected)
        explanation = render_text(fonts["small"], drug["explanation"], PASTEL_TEXT)
        surface.blit(explanation, explanation.get_rect(center=(x + 200, 603)))
    note = render_text(fonts["small"], "ختر الأدوية المناسبة لإغلاق المسارات الهرمونية والالتهابية وتخفيف الألم.", PASTEL_TEXT)
    surface.blit(note, note.get_rect(center=(640, 639)))
    draw_button(surface, pygame.Rect(500, 655, 280, 52), "اعتماد الخطة", fonts["button"])
    if notice:
        warning = render_text(fonts["small"], notice, (152, 72, 81))
        surface.blit(warning, warning.get_rect(center=(640, 481)))


def draw_battle_scene(surface, fonts, map_image, cells, macrophage_pos, elapsed, caught, attached):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    shade = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    shade.fill((250, 248, 245, 185))
    surface.blit(shade, (0, 0))
    pygame.draw.rect(surface, PASTEL_HEADER, (0, 0, SCREEN_WIDTH, 112))
    title = render_text(fonts["title"], "المعركة المناعية", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 42)))
    timer = render_text(fonts["body"], f"{max(0, math.ceil(30 - elapsed))} ثانية", PASTEL_TEXT)
    surface.blit(timer, (30, 72))
    stats = render_text(fonts["small"], f"ابتلعتِ {caught}   التصقت {attached}", PASTEL_TEXT)
    surface.blit(stats, (850, 78))
    instruction = render_text(fonts["small"], "حرّكي الخلية المناعية وانقري الخلايا لابتلاعها.", PASTEL_TEXT)
    surface.blit(instruction, instruction.get_rect(center=(640, 150)))

    pygame.draw.line(surface, (216, 116, 98), (0, 650), (SCREEN_WIDTH, 650), 6)
    for cell in cells:
        x, y = int(cell["x"]), int(cell["y"])
        pygame.draw.circle(surface, (98, 43, 57), (x, y), 17)
        pygame.draw.circle(surface, (214, 109, 124), (x, y), 12)
        pygame.draw.rect(surface, (245, 180, 161), (x - 4, y - 3, 8, 6))
        pygame.draw.rect(surface, (138, 64, 87), (x - 3, y + 5, 6, 4))

    mx, my = int(macrophage_pos[0]), int(macrophage_pos[1])
    pygame.draw.circle(surface, (229, 194, 131), (mx, my), 30)
    pygame.draw.circle(surface, (64, 130, 113), (mx, my), 24)
    pygame.draw.rect(surface, (228, 230, 197), (mx - 10, my - 6, 6, 6))
    pygame.draw.rect(surface, (228, 230, 197), (mx + 5, my - 6, 6, 6))
    pygame.draw.rect(surface, (40, 67, 61), (mx - 5, my + 8, 10, 4))
    footer = render_text(fonts["small"], "امسكي الخلايا قبل أن تلتصق بالجدار السفلي.", PASTEL_TEXT)
    surface.blit(footer, footer.get_rect(center=(640, 690)))


def draw_medal(surface, center, rank, size=48):
    ribbon_color = STRAWBERRY_ROSE if rank == "استشارية" else PASTEL_HEADER_DARK
    pygame.draw.polygon(
        surface,
        ribbon_color,
        (
            (center[0] - size // 4, center[1] + size // 4),
            (center[0], center[1] + size),
            (center[0] + size // 5, center[1] + size // 4),
        ),
    )
    medal_color = LEMON_MERINGUE if rank in ("استشارية", "أخصائية") else STRAWBERRY_CREAM
    pygame.draw.circle(surface, PASTEL_TEXT, center, size // 2 + 3)
    pygame.draw.circle(surface, medal_color, center, size // 2)
    pygame.draw.rect(surface, WARM_CREAM, (center[0] - 5, center[1] - 5, 10, 10))


def draw_trophy(surface, center):
    gold = LEMON_MERINGUE
    dark = PASTEL_HEADER_DARK
    x, y = center
    pygame.draw.rect(surface, gold, (x - 13, y - 11, 26, 18))
    pygame.draw.rect(surface, dark, (x - 17, y - 9, 5, 12))
    pygame.draw.rect(surface, dark, (x + 12, y - 9, 5, 12))
    pygame.draw.rect(surface, gold, (x - 4, y + 7, 8, 8))
    pygame.draw.rect(surface, gold, (x - 11, y + 15, 22, 5))


def draw_results_scene(surface, fonts, map_image, doctor_name, reason, score, storage_notice):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    panel = pygame.Rect(245, 34, 790, 654)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=20)
    pygame.draw.rect(surface, PASTEL_BORDER, panel, 4, border_radius=20)
    title = render_text(fonts["title"], "نتيجة الحالة", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 85)))
    total = render_text(fonts["title"], f"{score['total']} / 1000", PASTEL_HEADER_DARK)
    surface.blit(total, total.get_rect(center=(640, 145)))
    reason_surface = render_text(fonts["small"], reason, PASTEL_TEXT)
    surface.blit(reason_surface, reason_surface.get_rect(center=(640, 183)))

    labels = (
        ("السرعة", "speed"),
        ("ملاءمة العلاج", "treatment"),
        ("المعركة المناعية", "immune"),
        ("نفسية المريضة", "wellbeing"),
        ("الميزانية المتبقية", "budget"),
    )
    for index, (label, key) in enumerate(labels):
        y = 218 + index * 42
        label_surface = render_text(fonts["small"], label, PASTEL_TEXT)
        value_surface = render_text(fonts["small"], str(score[key]), PASTEL_TEXT)
        surface.blit(label_surface, (345, y))
        surface.blit(value_surface, (835, y))
    draw_medal(surface, (640, 470), score["rank"], 46)
    rank = render_text(fonts["body"], score["rank"], PASTEL_TEXT)
    surface.blit(rank, rank.get_rect(center=(640, 530)))
    name = render_text(fonts["small"], f"المعالجة: {doctor_name}", PASTEL_TEXT)
    surface.blit(name, name.get_rect(center=(640, 564)))
    note = render_text(fonts["small"], "تشخيص بطانة الرحم المهاجرة المبكر يقلل سنوات المعاناة للمريضات.", PASTEL_TEXT)
    surface.blit(note, note.get_rect(center=(640, 590)))
    if storage_notice:
        warning = render_text(fonts["small"], storage_notice, (152, 72, 81))
        surface.blit(warning, warning.get_rect(center=(640, 612)))
    draw_button(surface, pygame.Rect(405, 626, 220, 48), "لوحة الصدارة", fonts["small"])
    draw_button(surface, pygame.Rect(655, 626, 220, 48), "القائمة", fonts["small"])


def draw_leaderboard_scene(surface, fonts, map_image, entries, notice):
    surface.fill((0, 0, 0))
    surface.blit(map_image, (0, 0))
    panel = pygame.Rect(130, 34, 1020, 654)
    pygame.draw.rect(surface, WARM_CREAM, panel, border_radius=20)
    pygame.draw.rect(surface, PASTEL_BORDER, panel, 4, border_radius=20)
    title = render_text(fonts["title"], "لوحة الصدارة", PASTEL_TEXT)
    surface.blit(title, title.get_rect(center=(640, 82)))
    if entries:
        first = entries[0]
        prize = render_text(fonts["small"], f"{first['name']} — الأولى تفوز بجائزة", PASTEL_HEADER_DARK)
        surface.blit(prize, prize.get_rect(center=(640, 126)))
        draw_trophy(surface, (356, 126))
    else:
        empty = render_text(fonts["small"], "لا توجد نتائج حتى الآن.", PASTEL_TEXT)
        surface.blit(empty, empty.get_rect(center=(640, 126)))

    for index, entry in enumerate(entries[:10]):
        y = 162 + index * 43
        row = pygame.Rect(190, y, 900, 38)
        pygame.draw.rect(surface, STRAWBERRY_ROSE, row, border_radius=10)
        place = str(index + 1)
        left = render_text(fonts["small"], f"{place}  {entry['name']}", PASTEL_TEXT)
        right = render_text(fonts["small"], f"{entry['score']} — {entry['rank']}", PASTEL_TEXT)
        surface.blit(left, (220, y + 8))
        surface.blit(right, (735, y + 8))
        if index == 0:
            draw_trophy(surface, (202, y + 18))
    saved = render_text(fonts["small"], "تُحفظ النتائج على هذا الجهاز فقط.", PASTEL_TEXT)
    surface.blit(saved, saved.get_rect(center=(640, 610)))
    if notice:
        warning = render_text(fonts["small"], notice, (152, 72, 81))
        surface.blit(warning, warning.get_rect(center=(640, 636)))
    draw_button(surface, pygame.Rect(500, 650, 280, 40), "عودة", fonts["small"])


async def show_error(screen, message):
    font = pygame.font.Font(resource_path("assets/fonts/arabic_pixel.ttf"), 16)
    clock = pygame.time.Clock()
    lines = [line[:130] for line in message.splitlines()]
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
        screen.fill((36, 10, 10))
        for index, line in enumerate(lines[:36]):
            screen.blit(font.render(line, True, (255, 225, 225)), (12, 12 + index * 19))
        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


async def run_game(screen):
    map_image = pygame.image.load(resource_path("assets/images/hospital_map.png")).convert()
    map_image = pygame.transform.scale(map_image, (SCREEN_WIDTH, SCREEN_HEIGHT))
    map_mask = pygame.image.load(resource_path("assets/images/map_mask.png")).convert()
    map_mask = pygame.transform.scale(map_mask, (SCREEN_WIDTH, SCREEN_HEIGHT))
    player_sheet = pygame.image.load(resource_path("assets/images/player.png")).convert_alpha()
    player_frame = player_sheet.subsurface(pygame.Rect(0, 0, 26, 40))
    player_image = pygame.transform.scale(player_frame, (48, 72))
    fonts = {
        "title": load_font(48),
        "button": load_font(32),
        "body": load_font(24),
        "small": load_font(16),
        "tiny": load_font(8),
    }
    clock = pygame.time.Clock()
    state = "menu"
    doctor_name = ""
    name_text = ""
    name_notice = ""
    editing_name = False
    case = None
    previous_case_id = None
    day = 0
    certainty = 0
    player_pos = [600.0, 200.0]
    player_target = list(player_pos)
    show_reception_info = False
    current_room = None
    room_notice = ""
    result_reason = ""
    treatment_choices = set()
    treatment_fit = 0
    treatment_notice = ""
    battle_elapsed = 0.0
    battle_spawn_timer = 0.0
    battle_cells = []
    battle_caught = 0
    battle_attached = 0
    battle_spawned = 0
    macrophage_pos = [640.0, 560.0]
    score = None
    score_saved = False
    storage_notice = ""
    leaderboard_entries = []
    leaderboard_notice = ""
    leaderboard_return = "menu"
    animation_frame = 0

    def begin_case(name):
        nonlocal case, previous_case_id, day, certainty, show_reception_info
        nonlocal current_room, room_notice, result_reason
        nonlocal treatment_choices, treatment_fit, treatment_notice
        nonlocal battle_elapsed, battle_spawn_timer, battle_cells, battle_caught
        nonlocal battle_attached, battle_spawned, macrophage_pos
        nonlocal score, score_saved, storage_notice
        doctor_name = name.strip()[:24]
        if not doctor_name:
            return False
        case = new_case(previous_case_id)
        previous_case_id = case["id"]
        day = 0
        certainty = 0
        current_room = None
        room_notice = ""
        show_reception_info = False
        result_reason = ""
        treatment_choices = set()
        treatment_fit = 0
        treatment_notice = ""
        battle_elapsed = 0.0
        battle_spawn_timer = 0.0
        battle_cells = []
        battle_caught = 0
        battle_attached = 0
        battle_spawned = 0
        macrophage_pos = [640.0, 560.0]
        score = None
        score_saved = False
        storage_notice = ""
        return True

    def add_days(days):
        nonlocal day, certainty, state, result_reason
        day += days
        case["pain"] = min(100.0, case["pain"] + 1.5 * days)
        if case["pain"] >= 100:
            result_reason = "غادرت المريضة بعد تصاعد الألم."
            state = "results"
        elif case["budget"] <= 0:
            result_reason = "انتهت الميزانية المتاحة للحالة."
            state = "results"

    def finalize_result():
        nonlocal score, score_saved, leaderboard_entries, storage_notice
        if score is None:
            score = build_score_breakdown(
                case,
                day,
                treatment_fit,
                battle_caught,
                battle_attached,
                battle_spawned,
            )
        if not score_saved:
            entry = {
                "name": doctor_name,
                "score": score["total"],
                "rank": score["rank"],
            }
            leaderboard_entries, storage_notice = save_leaderboard_entry(entry)
            score_saved = True

    while True:
        clicked = False
        click_pos = None
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                clicked = True
                click_pos = event.pos
            elif event.type == pygame.FINGERDOWN:
                clicked = True
                click_pos = (
                    int(event.x * SCREEN_WIDTH),
                    int(event.y * SCREEN_HEIGHT),
                )
            elif event.type == pygame.MOUSEMOTION and state == "battle":
                macrophage_pos = [float(event.pos[0]), float(event.pos[1])]
            elif event.type == pygame.FINGERMOTION and state == "battle":
                macrophage_pos = [
                    float(event.x * SCREEN_WIDTH),
                    float(event.y * SCREEN_HEIGHT),
                ]
            elif event.type == pygame.TEXTINPUT and state == "name" and editing_name:
                name_text = (name_text + event.text)[:24]
            elif event.type == pygame.KEYDOWN and state == "name" and editing_name:
                if event.key == pygame.K_BACKSPACE:
                    name_text = name_text[:-1]
                elif event.key == pygame.K_RETURN:
                    if begin_case(name_text):
                        doctor_name = name_text.strip()[:24]
                        state = "case_intro"
                        editing_name = False
                        pygame.key.stop_text_input()
                    else:
                        name_notice = "اكتبي الاسم أولًا."

        mouse_pos = pygame.mouse.get_pos()
        portrait = is_portrait()

        if (
            clicked and click_pos is not None and state == "diagnosis"
            and not portrait and not show_reception_info
            and not RECEPTION_DESK_RECT.collidepoint(click_pos)
        ):
            control_rects = tuple(ROOM_BUTTON_RECTS.values()) + (CONFIRM_DIAGNOSIS_RECT,)
            if not any(rect.collidepoint(click_pos) for rect in control_rects):
                player_target = [
                    max(0.0, min(SCREEN_WIDTH - player_image.get_width(),
                                 click_pos[0] - player_image.get_width() / 2)),
                    max(64.0, min(SCREEN_HEIGHT - player_image.get_height(),
                                  click_pos[1] - player_image.get_height() / 2)),
                ]

        if clicked and click_pos is not None and not portrait:
            if show_reception_info:
                if RECEPTION_INFO_CLOSE_RECT.collidepoint(click_pos):
                    show_reception_info = False
            elif state in ("diagnosis", "room") and RECEPTION_DESK_RECT.collidepoint(click_pos):
                show_reception_info = True
            elif state == "menu":
                if pygame.Rect(450, 260, 380, 64).collidepoint(click_pos):
                    name_text = ""
                    name_notice = ""
                    if sys.platform == "emscripten":
                        try:
                            prompted_name = prompt_web_name()
                            prompt_value = str(prompted_name).strip() if prompted_name is not None else ""
                            if prompt_value and begin_case(prompt_value):
                                doctor_name = prompt_value[:24]
                                state = "case_intro"
                            else:
                                name_notice = "أدخلي اسمًا لبدء الحالة."
                                state = "name"
                        except Exception:
                            name_notice = "نافذة الاسم غير مدعومة هنا؛ اكتبي الاسم في الحقل."
                            editing_name = True
                            pygame.key.start_text_input()
                            state = "name"
                    else:
                        state = "name"
                        editing_name = True
                        pygame.key.start_text_input()
                elif pygame.Rect(450, 352, 380, 64).collidepoint(click_pos):
                    state = "how"
                elif pygame.Rect(450, 444, 380, 64).collidepoint(click_pos):
                    state = "leaderboard"
                    leaderboard_entries, leaderboard_notice = load_leaderboard()
                    leaderboard_return = "menu"
            elif state == "how":
                if pygame.Rect(500, 530, 280, 62).collidepoint(click_pos):
                    state = "menu"
            elif state == "leaderboard":
                if pygame.Rect(500, 650, 280, 40).collidepoint(click_pos):
                    state = leaderboard_return
            elif state == "name":
                if pygame.Rect(390, 350, 500, 60).collidepoint(click_pos):
                    editing_name = True
                    pygame.key.start_text_input()
                elif pygame.Rect(500, 450, 280, 62).collidepoint(click_pos):
                    if begin_case(name_text):
                        doctor_name = name_text.strip()[:24]
                        state = "case_intro"
                        editing_name = False
                        pygame.key.stop_text_input()
                    else:
                        name_notice = "اكتبي الاسم أولًا."
            elif state == "case_intro":
                if pygame.Rect(500, 520, 280, 62).collidepoint(click_pos):
                    state = "diagnosis"
            elif state in ("diagnosis", "room"):
                if state == "diagnosis" and certainty >= 70 and CONFIRM_DIAGNOSIS_RECT.collidepoint(click_pos):
                    state = "treatment"
                    treatment_choices = set()
                    treatment_notice = ""
                else:
                    selected_room = next(
                        (
                            test_id
                            for test_id, rect in ROOM_BUTTON_RECTS.items()
                            if rect.collidepoint(click_pos)
                        ),
                        None,
                    )
                    if selected_room:
                        current_room = selected_room
                        room_notice = ""
                        state = "room"
                    elif state == "room" and ROOM_PANEL_CLOSE_RECT.collidepoint(click_pos):
                        state = "diagnosis"
                        current_room = None
                        room_notice = ""
                    elif state == "room" and current_room is not None:
                        selected_test = next(
                            (
                                test_id
                                for test_id, rect in zip(
                                    ROOM_TEST_OPTIONS[current_room],
                                    ROOM_OPTION_BUTTON_RECTS[current_room],
                                )
                                if rect.collidepoint(click_pos)
                            ),
                            None,
                        )
                        if selected_test is not None:
                            test = TESTS[selected_test]
                            if selected_test in case["tests_used"]:
                                room_notice = "أُجري هذا الفحص مسبقًا."
                            elif case["budget"] < test["cost"]:
                                room_notice = "الميزانية لا تكفي لهذا الفحص."
                            else:
                                case["budget"] -= test["cost"]
                                case["tests_used"].add(selected_test)
                                modifier = case["modifiers"].get(selected_test, 0)
                                if selected_test == "laparoscopy":
                                    certainty = 100
                                else:
                                    certainty = min(
                                        100,
                                        max(0, certainty + test["certainty"] + modifier),
                                    )
                                add_days(test["days"])
                                room_notice = ""
            elif state == "treatment":
                drug_rects = {
                    "nsaids": pygame.Rect(30, 532, 380, 48),
                    "letrozole": pygame.Rect(450, 532, 380, 48),
                    "gnrh": pygame.Rect(870, 532, 380, 48),
                }
                toggled = next(
                    (drug_id for drug_id, rect in drug_rects.items() if rect.collidepoint(click_pos)),
                    None,
                )
                if toggled:
                    if toggled in treatment_choices:
                        treatment_choices.remove(toggled)
                    else:
                        treatment_choices.add(toggled)
                    treatment_notice = ""
                elif pygame.Rect(500, 655, 280, 52).collidepoint(click_pos):
                    treatment_cost = sum(DRUGS[drug]["cost"] for drug in treatment_choices)
                    if treatment_cost > case["budget"]:
                        treatment_notice = "الميزانية لا تكفي لهذه الخطة."
                    else:
                        case["budget"] -= treatment_cost
                        if case["budget"] <= 0:
                            result_reason = "انتهت الميزانية المتاحة للحالة."
                            state = "results"
                        else:
                            ideal = IDEAL_TREATMENTS[case["id"]]
                            matches = len(treatment_choices & ideal)
                            extras = len(treatment_choices - ideal)
                            treatment_fit = (
                                300
                                if treatment_choices == ideal
                                else max(0, min(300, matches * (300 // len(ideal)) - extras * 60))
                            )
                            pain_reduction = sum(
                                DRUGS[drug]["pain_effect"] for drug in treatment_choices
                            )
                            case["pain"] = max(0, case["pain"] - pain_reduction)
                            battle_elapsed = 0.0
                            battle_spawn_timer = 0.0
                            battle_cells = []
                            battle_caught = 0
                            battle_attached = 0
                            battle_spawned = 0
                            macrophage_pos = [640.0, 560.0]
                            state = "battle"
            elif state == "battle":
                macrophage_pos = [float(click_pos[0]), float(click_pos[1])]
                for index, cell in enumerate(battle_cells):
                    if not cell["attached"] and math.hypot(
                        cell["x"] - macrophage_pos[0],
                        cell["y"] - macrophage_pos[1],
                    ) <= 52:
                        battle_cells.pop(index)
                        battle_caught += 1
                        break
            elif state == "results":
                if pygame.Rect(405, 626, 220, 48).collidepoint(click_pos):
                    leaderboard_return = "results"
                    leaderboard_entries, leaderboard_notice = load_leaderboard()
                    state = "leaderboard"
                elif pygame.Rect(655, 626, 220, 48).collidepoint(click_pos):
                    state = "menu"
                    case = None
                    current_room = None
                    score = None

        if state == "diagnosis" and not portrait:
            move_delta = min(max(clock.get_time() / 1000.0, 0.0), 0.05)
            move_x = player_target[0] - player_pos[0]
            move_y = player_target[1] - player_pos[1]
            distance = math.hypot(move_x, move_y)
            step = 260 * move_delta
            if distance > 0:
                travel = min(step, distance)
                candidate_x = player_pos[0] + move_x / distance * travel
                candidate_y = player_pos[1] + move_y / distance * travel
                if can_move_to(
                    map_mask, candidate_x, candidate_y,
                    player_image.get_width(), player_image.get_height(),
                ):
                    player_pos[:] = [candidate_x, candidate_y]
                elif can_move_to(
                    map_mask, candidate_x, player_pos[1],
                    player_image.get_width(), player_image.get_height(),
                ):
                    player_pos[0] = candidate_x
                elif can_move_to(
                    map_mask, player_pos[0], candidate_y,
                    player_image.get_width(), player_image.get_height(),
                ):
                    player_pos[1] = candidate_y
                else:
                    player_target[:] = player_pos

        animation_frame += 1
        if state == "battle" and not portrait:
            battle_delta = min(max(clock.get_time() / 1000.0, 0.0), 0.05)
            battle_elapsed += battle_delta
            battle_spawn_timer += battle_delta
            while battle_spawn_timer >= 0.9 and battle_elapsed < 30:
                battle_spawn_timer -= 0.9
                battle_cells.append({
                    "x": float(random.randint(30, SCREEN_WIDTH - 30)),
                    "y": float(random.randint(175, 340)),
                    "vx": random.uniform(-18, 18),
                    "vy": random.uniform(38, 70),
                    "attached": False,
                })
                battle_spawned += 1
            for cell in battle_cells:
                if cell["attached"]:
                    continue
                cell["x"] += cell["vx"] * battle_delta
                cell["y"] += cell["vy"] * battle_delta
                if cell["x"] < 24 or cell["x"] > SCREEN_WIDTH - 24:
                    cell["vx"] *= -1
                    cell["x"] = max(24, min(SCREEN_WIDTH - 24, cell["x"]))
                if cell["y"] >= 640:
                    cell["y"] = 640
                    cell["attached"] = True
                    battle_attached += 1
            if battle_elapsed >= 30:
                result_reason = "اكتملت المواجهة المناعية."
                state = "results"

        if state == "results":
            finalize_result()

        if portrait:
            screen.fill((18, 30, 36))
            rotate = render_text(fonts["title"], "أديري هاتفك للوضع الأفقي", (255, 244, 222))
            screen.blit(rotate, rotate.get_rect(center=(640, 360)))
        elif state in ("menu", "how"):
            draw_menu(screen, state, fonts, map_image, mouse_pos)
        elif state == "leaderboard":
            draw_leaderboard_scene(
                screen, fonts, map_image, leaderboard_entries, leaderboard_notice,
            )
        elif state == "name":
            draw_name_screen(screen, fonts, map_image, name_text, editing_name, name_notice)
        elif state == "case_intro":
            draw_case_intro(screen, case, doctor_name, fonts, map_image)
        elif state in ("diagnosis", "room"):
            draw_map_scene(
                screen, case, day, certainty, fonts, map_image,
                player_image, player_pos, case["tests_used"], mouse_pos,
                state == "diagnosis",
            )
            if state == "room":
                draw_room_panel(screen, current_room, case, fonts, room_notice, mouse_pos)
            if show_reception_info:
                draw_reception_info(screen, fonts, mouse_pos)
        elif state == "treatment":
            draw_treatment_scene(
                screen, case, treatment_choices, fonts, map_image,
                animation_frame, treatment_notice,
            )
        elif state == "battle":
            draw_battle_scene(
                screen, fonts, map_image, battle_cells, macrophage_pos,
                battle_elapsed, battle_caught, battle_attached,
            )
        elif state == "results":
            draw_results_scene(
                screen, fonts, map_image, doctor_name, result_reason,
                score, storage_notice,
            )
        else:
            draw_menu(screen, "menu", fonts, map_image, mouse_pos)

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


async def main():
    screen = None
    try:
        pygame.init()
        screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
        pygame.display.set_caption("Diagnosis Hour")
        await run_game(screen)
    except Exception:
        error_text = traceback.format_exc()
        traceback.print_exc()
        if screen is not None:
            await show_error(screen, error_text)


asyncio.run(main())
